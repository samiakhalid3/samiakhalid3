const express = require('express');
const reservationsController = require('../controllers/reservationsController');
const isLoginadmin = require("../middleware/isLoginadmin");
const isLogin = require("../middleware/isLogin");
const { check } = require('express-validator');

const router = express.Router();







router.post('/newReservation' ,  reservationsController.add_reservation);

router.post('/viewUserReservation' ,  reservationsController.find_reservations);

router.get('/viewAllReservation' ,  reservationsController.view_reservations);

router.post('/delete', reservationsController.delete_reservation);

module.exports = router;