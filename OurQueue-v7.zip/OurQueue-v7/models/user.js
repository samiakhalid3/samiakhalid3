const mongoose = require("mongoose");

const AutoIncrement = require("mongoose-sequence")(mongoose);

const Schema = mongoose.Schema;

const userSchema = new Schema({
  unique_id: Number,

  userId: {
    type: Number,
    unique: true,
  },

  username: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  
  password: {
    type: String,
    required: true,
  },


  phone: {
    type: Number,
    required: true,
  },
});
userSchema.plugin(AutoIncrement, { inc_field: "userId" });
module.exports = mongoose.model("User", userSchema);