const express = require('express');
const session = require('express-session');
const mongoose = require('mongoose');
const MongoDBStore = require('connect-mongodb-session')(session);
require('dotenv').config();




const app = express();
app.set("view engine", "ejs");
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

let sessionStore = new MongoDBStore({
	uri: process.env.MONGO_URI,
	collection: 'mySessions'
});

// Catch errors
sessionStore.on('error', function(error) {
  console.log(error);
});

// configure session middleware
app.use(session({
	secret: process.env.SESSION_SECRET,
	cookie: {
    maxAge: 1000 * 60 * 60 * 24 * 7, // 1 week
  },
	saveUninitialized: true,
	resave: true,
	store: sessionStore
}));

//=================== Routes



/////////////admin////////////////////

const adminRouter = require('./routes/adminRoutes');

app.use('/', adminRouter);


//////////reservation//////////////////////////////////
const reservationsRouter = require('./routes/reservationsRoutes');

app.use('/', reservationsRouter);
//////////////////////user//////////////////////
const userRouter = require('./routes/userRoutes');

app.use('/', userRouter);


/////////////////////////////////////////////////////
///////////////////Define routes for each page//////////////////////////////////



// 
app.get('/', (req, res) => {
  res.render('index');
});



app.get('/login', (req, res) => {
  res.render('login');
});

app.get('/register', (req, res) => {
  res.render('register');
});

app.get('/about', (req, res) => {
  res.render('about');
});

app.get('/menu', (req, res) => {
  res.render('menu');
});

app.get('/FAQ', (req, res) => {
  res.render('FAQ');
});

app.get('/contact', (req, res) => {
  res.render('contact');
});


app.get('/deleted', (req, res) => {
  res.render('deleted');
});

app.get('/success', (req, res) => {
  res.render('success');
});
///////////////////////////////////////////////////
// Connect to database then start server
mongoose.connect(process.env.MONGO_URI)
  .then((result) => {
    console.log("Connected to database...");
    app.listen(process.env.port, 'localhost', () => {
      console.log(`Listening on port ${process.env.PORT}`);
    });
  })
  .catch((err) => {
    console.log(err);
  });
